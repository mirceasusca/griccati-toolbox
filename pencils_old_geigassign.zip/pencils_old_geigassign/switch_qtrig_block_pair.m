function [At,Et,QS,ZS] = switch_qtrig_block_pair(At,Et,k,pos)
%SWITCH_QTRIG_BLOCK Switches the matrix block of size k x k from
% the end of the matrix to the position pos.
%
% [At,Et,QS,ZS] = switch_qtrig_block_pair(At,Et,k,pos)
%
n = size(At,1);
assert(pos+k-1 <= n,'Error: end index too large to place block.');
assert(pos >= 1,'Error: must request pos greater or equal to one.');

idx = n-k+1; % current position
%
QS = eye(size(At)); % TODO, what if it is rectangular
ZS = eye(size(Et)); 
% for debug
% At0 = At;
% Et0 = Et;
%
if pos == n % no need to switch x with x...
    return;
end
%
while idx > pos
    if has_1x1_block_above(At,idx)
        n1 = 1;
    else
        n1 = 2;
    end
    [V,W] = reord_schur_consecutive_blocks_pair(...
        At(idx-n1:idx+k-1,idx-n1:idx+k-1),...
        Et(idx-n1:idx+k-1,idx-n1:idx+k-1),n1,k);
    %
    Q1 = eye(n);
    Q1(idx-n1:idx+k-1,idx-n1:idx+k-1) = V;
    %
    Z1 = eye(n);
    Z1(idx-n1:idx+k-1,idx-n1:idx+k-1) = W;
    %
    At = Q1'*At*Z1;
    Et = Q1'*Et*Z1;
    QS = QS*Q1;
    ZS = ZS*Z1;
    % for debug
    % QS'*At0*ZS-At
    % QS'*Et0*ZS-Et
    %
    % [At,Et] = zero_negligible_elements(At,Et);
    %
    [At,Et,QG] = triangularize_matrix(At,Et);
    QS = QS*QG;
    % QS'*At0*ZS-At
    % QS'*Et0*ZS-Et
    %
%     [At(idx-n1:idx+k-1,idx-n1:idx+k-1),Et(idx-n1:idx+k-1,idx-n1:idx+k-1)] ...
%         = zero_negligible_elements(...
%        At(idx-n1:idx+k-1,idx-n1:idx+k-1),...
%        Et(idx-n1:idx+k-1,idx-n1:idx+k-1));
    %
    idx = idx - n1;
end

end

function has_1x1_block = has_1x1_block_above(A,idx)
%HAS_1X1_BLOCK_ABOVE Checks if matrix A has a 1x1 or a 2x2 block above the
% diagonal index idx.
%
% has_1x1_block = has_1x1_block_above(A,idx)
%

has_1x1_block = true;
%
% if idx < 3, there is no space for a 2x2 block
if idx >= 3
    c = 4;
    if abs(A(idx-1,idx-2)) > c*(eps(A(idx-1,idx-1)) + eps(A(idx-2,idx-2)))
        has_1x1_block = false;
    end
end
%
end

function [A,B,QG] = triangularize_matrix(A,B)
n = size(A,1);
idx = 0;
%
QG = eye(n);
for i = 2:n
    if abs(B(i,i-1)) > 4*(eps(B(i-1,i-1)) + eps(B(i,i)))
        idx = i;
        break
    end
end

if idx > 0
    G = givens(B(idx-1,idx-1),B(idx,idx-1));
    %
    QG(idx-1:idx,idx-1:idx) = G';
    %
    A = QG'*A;
    B = QG'*B;
end

end
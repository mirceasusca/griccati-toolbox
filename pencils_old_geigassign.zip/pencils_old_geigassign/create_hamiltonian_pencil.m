function [M,N] = create_hamiltonian_pencil(sigma)
%
A = sigma.A;
B = sigma.B;
%
n = size(A,1);
m = size(B,2);
%
Q = sigma.Q;
L = sigma.L;
R = sigma.R;
%
M = zeros(2*n+m);
%
if sigma.discr == false
    M(1:2*n,1:2*n) = eye(2*n);
    %
    N = [A, zeros(size(A)), B;
        -Q, -A', -L;
        L', B', R];
else
    M(1:n,1:n) = eye(n);
    M(n+1:2*n,n+1:2*n) = -A';
    M(2*n+1:end,n+1:2*n) = -B';
    %
    N = [A, zeros(size(A)), B;
        Q, -eye(size(A)), L;
        L', zeros(size(B')), R];
end

end
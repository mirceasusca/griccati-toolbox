function [At,US] = switch_qtrig_block_single(At,k,pos)
%SWITCH_QTRIG_BLOCK Switches the matrix block of size k x k from
% the end of the matrix to the position pos.
%
% TODO: interface call
%
n = size(At,1);
assert(pos+k-1 <= n,'Error: end index too large to place block.');
assert(pos >= 1,'Error: must request pos greater or equal to one.');

idx = n-k+1; % current position
%
At0 = At; % for debug
%
US = eye(size(At)); % TODO, what if it is rectangular
%
if pos == n % no need to switch x with x...
    return;
end
%
while idx > pos
    if has_1x1_block_above(At,idx)
        n1 = 1;
    else
        n1 = 2;
    end
    V = reord_schur_consecutive_blocks(At(idx-n1:idx+k-1,idx-n1:idx+k-1),n1,k);
    %
    Q1 = eye(n);
    Q1(idx-n1:idx+k-1,idx-n1:idx+k-1) = V;
%     Af = At(idx-n1:idx+k-1,idx-n1:idx+k-1);
%     Ef = Et(idx-n1:idx+k-1,idx-n1:idx+k-1);
    %
    At = Q1'*At*Q1;
    %
    US = Q1*US;
    %
    idx = idx - n1;
end
US = US';
% disp('debug');
end

function has_1x1_block = has_1x1_block_above(A,idx)
%HAS_1X1_BLOCK_ABOVE Checks if matrix A has a 1x1 or a 2x2 block above the
% diagonal index idx.
%
% has_1x1_block = has_1x1_block_above(A,idx)
%

has_1x1_block = true;
%
% if idx < 3, there is no space for a 2x2 block
if idx > 3
    c = 4;
    if abs(A(idx-1,idx-2)) > c*(eps(A(idx-1,idx-1)) + eps(A(idx-2,idx-2)))
        has_1x1_block = false;
    end
end
%
end
function [r,nu_r,nu_l] = nrankp_info(info,m,n)
%NRANK Computes normal rank of matrix pencil A-lambda*E given the info 
% stucture returned from a gklf call.
%
% nu_r := n - r > 0 then the pencil has right singular structure
% nu_l := m - r > 0 then the pencil has left singular structure
%
% [r,nu_r,nu_l] = nrank(A,E,tol)
%

r = sum(info.minf) + info.mf;
[rkr,rkc] = extract_kronecker_structure(info,'right');
[lkr,lkc] = extract_kronecker_structure(info,'left');
r = r + rkr + lkc;

nu_r = n - r;
nu_l = m - r;

assert(nu_r == 0);
assert(nu_l == 0);

assert(r <= m && r <= n);

end


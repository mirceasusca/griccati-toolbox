function [At,Et,Q,Z] = ord_eig_6_53(At,Et,Q,Z,n_start,opts)
%ORD_EIG_6_53 Orders matrix pencil At-lambda*Et as in relation (6.53), with
% ninf infinite generalized eigenvalues first, then n1 eigenvalues in Cg, 
% n2 eigenvalues in Cb using only unitary transformations Q and Z:
% Q'*A*Z = At, Q'*E*Z = Et. 
%  The parameter n_start specifies the starting
% position index for the first set of eigenvalues.
%
% [At,Et,Q,Z] = ord_eig_6_53(At,Et,Q,Z,n_start)
%

Af = At(n_start:end,n_start:end);
Ef = Et(n_start:end,n_start:end);
%
% [AAf,EEf,QS,ZS]=gsorsf(Af,Ef); % ord. gen. real Schur form
[~,~,QS,ZS]=gsorsf(Af,Ef,opts); % ord. gen. real Schur form
% below only as assertions
% QS*AAf*ZS'-Af == 0
% EEf-QS'*Ef*ZS == 0
%
QQS = eye(size(At)); ZZS = eye(size(At));
QQS(n_start:end,n_start:end) = QS;
ZZS(n_start:end,n_start:end) = ZS;
%
% Ainf = At(1:ninf,1:ninf);
% Einf = Et(1:ninf,1:ninf);
% XA = At(1:ninf,ninf+1:end);
% XE = Et(1:ninf,ninf+1:end);
%
% pencil as in (6.53), pg. 208
% Att = QQS'*At*ZZS;
% Ett = QQS'*Et*ZZS;
% below only as assertions
% At - QQS*Att*ZZS' == 0
% Et - QQS*Ett*ZZS' == 0
% A-Q*QQS*Att*ZZS'*Z' == 0
% E-Q*QQS*Ett*ZZS'*Z' == 0

% pencil as in (6.53), pg. 208
At = QQS'*At*ZZS;
Et = QQS'*Et*ZZS;
Q = Q*QQS;
Z = Z*ZZS;
% Q'*A*Z-At == 0
% E-Q*Et*Z' == 0
end


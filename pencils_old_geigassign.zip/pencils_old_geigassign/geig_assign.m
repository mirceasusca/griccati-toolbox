function [F,info] = geig_assign(M,N,B,varargin)
%GEIG_ASSIGN Computes feedback matrix F which stabilzes the 
% generalized state-space system:
%   M*dx/dt = N*x + B*u, using the attached regular matrix pencil:
%  [M*lambda-N | B]
%
% TODO: instead of reordering in ninf, n1, n2 just keep an indexation with
% the eigenvalues to be moved as in [0,0,1,1,0,1]. It reduces the number of
% reorderings and computations.
%
% Implements Algorithm 1 from page 208.
% Remark: gklf(A,E) computes results for the pencil A - lambda*E.
%

% Rename variables for easier interfacing with gklf
A = -N;
E = -M; 

opts.thr = -2;  % for lhp
opts.disc = false;
%
info.code = 0;
[n,m] = size(B);
F = zeros(m,n);  % (*)

[reg,At,Et,gklf_info,Q,Z] = isregular(A,E);  % At./Et == N/M -- consider M = I
% for debug
% Q'*A*Z-At == 0
% E-Q*Et*Z' == 0

if ~reg
    error('Matrix pencil must be regular.');
elseif size(A,1) ~= size(B,1)
    error('B must have the same number of rows as M and N.');
end

% TODO: check controllability of the pencil [M*lambda-N | B]

ninf = 0;  % number of infinite generalized eigenvalues
for i = 1:length(gklf_info.minf)
    ninf = ninf + gklf_info.minf(i);
end
%
nf = size(A,1)-ninf;  % number of finite generalized eigenvalues
assert(nf == gklf_info.mf,['Computed number of finite eigenvalues does',...
    ' not coincide with returned number from gklf.']);

% after determining the ninf infinite eigenvalues, apply the ordered QZ
% algorithm to the subpencil Af-lambda*Ef only, avoids the ill conditioned
% "computation" of the infinite eigenvalues performed by the QZ algorithm
% in the case of multiple infinite eigenvalues

% 1) order eigenvalues as in (6.53), pg. 208
[At,Et,Q,Z] = ord_eig_6_53(At,Et,Q,Z,ninf+1,opts);
[At,Et] = zero_negligible_elements(At,Et);

[n1v_idx,n2v_idx,n1v,n2v] = get_part_cg_cb(...
    At(ninf+1:end,ninf+1:end),...
    Et(ninf+1:end,ninf+1:end),opts);
n1 = sum(n1v_idx);
% n2 = sum(n2v);

Bt = Q'*B;

t = ninf + n1; 
% initialization of F as in (*); placed up so that the function has all its
% return values

% use (M-I*thr)*lambda - N for computation if a desired distance from the
% imaginary axis

% 2) if t == n STOP; equiv. to all eigenvalues already placed correctly
if t == n
    return;
end

nrmBt = max(1,norm(Bt,1));
fnrmtol = 100*max(1,norm(At,1))/nrmBt;

% 3)
for i = length(n2v_idx):-1:1
    
    k = n2v_idx(i);
    %
    poles = get_closed_loop_poles(k,n2v{i},opts);
    %
    idx = n-k+1:n;
    f = get_block_feedback(At(idx,idx),Et(idx,idx),Bt(idx,:),poles);
    %
    if isempty(f)
        warning('Block not controllable.');
    else
        if norm(f,inf) > fnrmtol
            warning('Possible loss of numerical reliability due to high feedback gain')
        end
        At(:,idx) = At(:,idx) + Bt*f; % N_bar <- N_bar + B*f
        F = F + f*Z(:,idx)';
    end
    
    % 4) Use an algorithm for swapping eigenvalues in the generalized Schur
    % form to move the last k generalized eigenvalues of lambda*Mbar-Nbar
    % to the position t+1
    [At,Et,Q1,Z1] = switch_qtrig_block_pair(At,Et,k,t+1);
    % for debug
    % Q1'*At*Z1-At2 == 0
    % Q1*At2*Z1'-At
    [At,Et] = zero_negligible_elements(At,Et);
    
    Bt = Q1'*Bt;
    Q = Q1'*Q;
    Z = Z*Z1;
    %
    t = t + k;
end
    
end

function poles = get_closed_loop_poles(k,ol_poles,opts)
% TODO: add as argument the current transfer function poles and improve
% them or make assignments structurally similar to them
%
% ol_poles: open-loop poles
% poles: closed-loop poles
%
    if k == 1
        if opts.disc == false
            poles = opts.thr;
        else
            error('Not implemented yet.');
        end
    elseif k == 2
        if opts.disc == false
            alpha = opts.thr;
            beta = imag(ol_poles(1));
            poles = [alpha+1j*beta,alpha-1j*beta];
        else
            error('Not implemented yet.');
        end
    else
        error('Blocks must have size 1x1 or 2x2.');
    end
end

function f = get_block_feedback(At,Et,Bt,poles)
% Bt*Btpinv should have something with I if controllable

n = size(At,1);
m = size(Bt,2);

if length(poles) == 2
    tolA = n*n*eps(max(1,norm(At,1))); % used for controllability checks
    tolB = n*m*eps(max(1,norm(At,1)));
    [f,~,~] = galoc2(At,Et,Bt,poles,tolA,tolB);
else
    if Bt ~= 0
        f = Bt\(Et*poles(1)-At);
    else
        f = [];
    end
end
%
if isempty(f)
    warning('Block not controllable.');
end

end

function V = reord_schur_consecutive_blocks_single(A,n1,n2)
%REORD_SCHUR Given a real Schur matrix of size n=n1+n2, the algorithm
% computes an orthogonal matrix V so that:
% V'*A*V = V'*[A11,A12;0,A22]*V = [A11_tilde, A12_tilde; 0, A22_tilde],
% with lambda(A11) = lambda(A22_tilde), lambda(A22) = lambda(A11_tilde).
%
% V = reord_schur(A,n1,n2)
%

n = size(A,1);
A11 = A(1:n1,1:n1);
A22 = A(n-n2+1:end,n-n2+1:end);
A12 = A(1:n1,n-n2+1:end);

gamma = 1e-5+(1-1e-5)*rand(1,1); % in (0,1] prevents  possible overflow 
X = sylvester(A11,-A22,gamma*A12);
if any(~isfinite(X))
    warning(['reord_schur_consecutive_blocks: ',...
        'matrix singular to working precision ',...
        'or blocks have common eigenvalues.']);
end

% I1 = eye(n1);
I2 = eye(n2);
% A0 = [A11,A12;zeros(size(A12')),A22];
% O = zeros(size(A12));
% [I1,-X;O',gamma*I2]*[A11,O;O',A22]*[I1,X/gamma;O',I2/gamma]

[V,~] = qr([-X;gamma*I2]);
% R = Re(1:n2,1:n2)
% V12 = V(1:n1,n-n1+1:n)

end


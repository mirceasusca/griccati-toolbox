function [F,X,info] = gricsv(sigma)
%GRICSV Summary of this function goes here
% Generalized Riccati System Solver
% Implements Algorithm 3 -- pg. 212
%   Detailed explanation goes here

info = struct();

if sigma.discr == true
    info.system = 'GDTARS';
else
    info.system = 'GCTARS';
end

n = size(sigma.A,1); % system order
m = size(sigma.B,2); % number of inputs

[M,N] = create_hamiltonian_pencil(sigma);

% Step 1)
[V,mpdef_info] = mpdefsub(M,N,sigma.discr,sigma.margin);
[rnk,nu_r,nu_l] = nrankp_info(mpdef_info.kron_info,size(M,1),size(M,2));
info.V = V;
info.S = mpdef_info.S;

nr = mpdef_info.nr;
ng = mpdef_info.ng;

% if nu_r > 0
if rnk ~= size(M,1)
    info.regular = false;
    warning('Pencil is singular.');
else
    info.regular = true;
end

% Step 2)
if nr + ng < n
    error(['There exists no solution of maximal dimension to the ',info.system]);
end

% Step 3) already done in mpdefsub
% if nr == 0
%     % check V for the regular case computed using Steps 1-3 of algorithm 2
%     disp('No right Kronecker structure.');
% else
%     disp('Has right Kronecker structure.');
%     % check V computed using Step 4 of algorithm 2
% end

% Step 4) partition V as in (6.6) or (6.31)
V1 = V(1:n,:);
V2 = V(n+1:2*n,:);
V3 = V(2*n+1:end,:);

if rank(V1) < n
    error(['There exists no solution of maximal dimension to the ',info.system]);
end

% Step 5)
r = nr + ng;
info.r = r;

if r == n
    % CTARS/DTARS solution: (X,F)
    X = V2/V1;
    F = V3/V1;
elseif r < n
    % GCTARS/GDTARS solution: (X,F,r,V1)
    V1pinv = pinv(V1);
    X = V2*V1pinv;
    F = V3*V1pinv;
else
    error(['There exists no solution of maximal dimension to the ',info.system]);
end

end


function [r,nu_r,nu_l] = nrankp(A,E,tol)
%NRANK Computes normal rank of matrix pencil A-lambda*E.
% nu_r := n - r > 0 then the pencil has right singular structure
% nu_l := m - r > 0 then the pencil has left singular structure
%
% [r,nu_r,nu_l] = nrank(A,E,tol)
%

[m,n] = size(A);
[m1,n1] = size(E);

if m ~= m1 || n ~= n1
    error('Incompatible matrix pencil.');
end

if nargin < 3
    tol = 0;
end

[~,~,info] = gklf(A,E,tol);

r = sum(info.minf) + info.mf;
[rkr,rkc] = extract_kronecker_structure(info,'right');
[lkr,lkc] = extract_kronecker_structure(info,'left');
r = r + rkr + lkc;

nu_r = n - r;
nu_l = m - r;

assert(r <= m && r <= n);

end


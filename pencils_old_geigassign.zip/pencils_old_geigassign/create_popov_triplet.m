function sigma = create_popov_triplet(A,B,Q,L,R,discr,margin)
%CREATE_POPOV_TRIPLET

sigma = struct();

compatible_triplet = ...
    (size(A,1) == size(A,2)) && ...
    (size(B,1) == size(A,1)) && ...
    (size(B,2) == size(R,1)) && ...
    (size(Q,1) == size(Q,2)) && ...
    (size(R,1) == size(R,2)) && ...
    (size(L,1) == size(Q,1)) && ...
    (size(L,2) == size(R,1));
if ~compatible_triplet
    error('Incompatible performance index dimensions.');
end

sigma.A = A;
sigma.B = B;
%
sigma.Q = Q;
sigma.L = L;
sigma.R = R;
%
if nargin == 5
    sigma.discr = false;
    sigma.margin = -0.2;
elseif nargin == 6
    sigma.discr = discr;
    if discr == false
        sigma.margin = -0.2;
    else
        sigma.margin = 0.95;
    end
elseif nargin == 7
    sigma.discr = discr;
    sigma.margin = margin;
else
    error('Unexpected input arguments.');
end
    
end
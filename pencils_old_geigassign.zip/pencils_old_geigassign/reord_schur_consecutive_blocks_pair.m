function [V,W] = reord_schur_consecutive_blocks_pair(A,B,n1,n2)
%REORD_SCHUR 

n = size(A,1);
%
A11 = A(1:n1,1:n1);
A22 = A(n-n2+1:end,n-n2+1:end);
A12 = A(1:n1,n-n2+1:end);
%
B11 = B(1:n1,1:n1);
B22 = B(n-n2+1:end,n-n2+1:end);
B12 = B(1:n1,n-n2+1:end);

gamma = 1e-5+(1-1e-5)*rand(1,1); % in (0,1] prevents  possible overflow
%
[X,Y] = sylvester_gen_slv(A11,-A22,gamma*A12,B11,-B22,gamma*B12);
if any(~isfinite(X(:))) || any(~isfinite(Y(:)))
    warning(['reord_schur_consecutive_blocks: ',...
        'matrix singular to working precision ',...
        'or blocks have common eigenvalues.']);
end

% I1 = eye(n1);
I2 = eye(n2);
%
% A0 = [A11,A12;zeros(size(A12')),A22];
% O = zeros(size(A12));
% [I1,-X;O',gamma*I2]*[A11,O;O',A22]*[I1,X/gamma;O',I2/gamma]
% %
% B0 = [B11,B12;zeros(size(B12')),B22];
% O = zeros(size(B12));
% [I1,-Y;O',gamma*I2]*[B11,O;O',B22]*[I1,Y/gamma;O',I2/gamma]

[V,~] = qr([-Y;gamma*I2]);
[W,~] = qr([-X;gamma*I2]);
% R = Re(1:n2,1:n2)
% V12 = V(1:n1,n-n1+1:n)

end

